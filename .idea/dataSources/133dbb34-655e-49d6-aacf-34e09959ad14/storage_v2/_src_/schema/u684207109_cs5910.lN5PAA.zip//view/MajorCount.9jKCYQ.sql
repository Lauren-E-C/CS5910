create definer = u684207109_cs5910@`75.127.200.98` view MajorCount as
select `u684207109_cs5910`.`StudentMajor`.`MajorName`        AS `MajorName`,
       count(`u684207109_cs5910`.`StudentMajor`.`MajorName`) AS `MajorCount`
from `u684207109_cs5910`.`StudentMajor`
group by `u684207109_cs5910`.`StudentMajor`.`MajorName`
order by count(`u684207109_cs5910`.`StudentMajor`.`MajorName`) desc;

