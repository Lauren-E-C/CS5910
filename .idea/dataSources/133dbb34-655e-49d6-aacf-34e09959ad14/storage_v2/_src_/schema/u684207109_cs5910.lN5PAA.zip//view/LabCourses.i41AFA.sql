create definer = u684207109_cs5910@`75.127.200.98` view LabCourses as
select `LabSection`.`CourseRegistrationNumber`      AS `CourseRegistrationNumber`,
       `LabSection`.`CourseID`                      AS `CourseID`,
       `LabSection`.`SectionNumber`                 AS `SectionNumber`,
       `LabSection`.`FacultyID`                     AS `LabSection_FacultyID`,
       `LabSection`.`TimeSlotNum`                   AS `TimeSlotNum`,
       `LabSection`.`SeatsCapacity`                 AS `SeatsCapacity`,
       `LabSection`.`RoomID`                        AS `RoomID`,
       `LabSection`.`BuildingName`                  AS `BuildingName`,
       `LabSection`.`Semester`                      AS `Semester`,
       `LabSection`.`Year`                          AS `Year`,
       `LabSection`.`departmentcode`                AS `departmentcode`,
       `LabSection`.`coursenumber`                  AS `coursenumber`,
       `LabSection`.`coursename`                    AS `coursename`,
       `LabSection`.`description`                   AS `description`,
       `LabSection`.`level`                         AS `level`,
       `LabSection`.`prerequisites`                 AS `prerequisites`,
       `LabSection`.`credits`                       AS `credits`,
       `u684207109_cs5910`.`ClassList`.`StudentID`  AS `StudentID`,
       `u684207109_cs5910`.`ClassList`.`FacultyID`  AS `ClassList_FacultyID`,
       `u684207109_cs5910`.`ClassList`.`TermNumber` AS `TermNumber`,
       count(`LabSection`.`CourseID`)               AS `LabCount`
from (select `u684207109_cs5910`.`Section`.`CourseRegistrationNumber` AS `CourseRegistrationNumber`,
             `u684207109_cs5910`.`Section`.`CourseID`                 AS `CourseID`,
             `u684207109_cs5910`.`Section`.`SectionNumber`            AS `SectionNumber`,
             `u684207109_cs5910`.`Section`.`FacultyID`                AS `FacultyID`,
             `u684207109_cs5910`.`Section`.`TimeSlotNum`              AS `TimeSlotNum`,
             `u684207109_cs5910`.`Section`.`SeatsCapacity`            AS `SeatsCapacity`,
             `u684207109_cs5910`.`Section`.`RoomID`                   AS `RoomID`,
             `u684207109_cs5910`.`Section`.`BuildingName`             AS `BuildingName`,
             `u684207109_cs5910`.`Section`.`Semester`                 AS `Semester`,
             `u684207109_cs5910`.`Section`.`Year`                     AS `Year`,
             `u684207109_cs5910`.`Course`.`departmentcode`            AS `departmentcode`,
             `u684207109_cs5910`.`Course`.`coursenumber`              AS `coursenumber`,
             `u684207109_cs5910`.`Course`.`coursename`                AS `coursename`,
             `u684207109_cs5910`.`Course`.`description`               AS `description`,
             `u684207109_cs5910`.`Course`.`level`                     AS `level`,
             `u684207109_cs5910`.`Course`.`prerequisites`             AS `prerequisites`,
             `u684207109_cs5910`.`Course`.`credits`                   AS `credits`
      from `u684207109_cs5910`.`Section`
               join `u684207109_cs5910`.`Course`
      where `u684207109_cs5910`.`Section`.`RoomID` in (select `u684207109_cs5910`.`Room`.`RoomID`
                                                       from `u684207109_cs5910`.`Room`
                                                       where lcase(`u684207109_cs5910`.`Room`.`RoomType`) like '%lab%')
        and `u684207109_cs5910`.`Section`.`CourseID` = `u684207109_cs5910`.`Course`.`courseID`) `LabSection`
         join `u684207109_cs5910`.`ClassList`
where `u684207109_cs5910`.`ClassList`.`CourseRegistrationNumber` = `LabSection`.`CourseRegistrationNumber`
group by `LabSection`.`CourseID`
order by count(`LabSection`.`CourseID`) desc;

