create definer = u684207109_cs5910@`75.127.200.98` view CompSciMajor as
select `Y`.`CompSciMajor` AS `CompSciMajor`, count(`Y`.`CompSciMajor`) AS `CompSciCount`
from (select if(`u684207109_cs5910`.`StudentMajor`.`MajorName` = 'Computer Science', 'Computer Science',
                'Non Computer Science') AS `CompSciMajor`
      from `u684207109_cs5910`.`StudentMajor`
      where `u684207109_cs5910`.`StudentMajor`.`StudentID` in
            (select distinct `u684207109_cs5910`.`ClassList`.`StudentID`
             from `u684207109_cs5910`.`ClassList`
             where `u684207109_cs5910`.`ClassList`.`CourseRegistrationNumber` in
                   (select `u684207109_cs5910`.`Section`.`CourseRegistrationNumber`
                    from `u684207109_cs5910`.`Section`
                    where `u684207109_cs5910`.`Section`.`CourseID` in (select `u684207109_cs5910`.`Course`.`courseID`
                                                                       from `u684207109_cs5910`.`Course`
                                                                       where `u684207109_cs5910`.`Course`.`departmentcode` = 'CSC')))) `Y`
group by `Y`.`CompSciMajor`;

