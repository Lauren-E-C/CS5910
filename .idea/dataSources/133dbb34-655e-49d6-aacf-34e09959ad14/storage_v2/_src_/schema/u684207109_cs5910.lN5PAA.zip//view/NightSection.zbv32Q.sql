create definer = u684207109_cs5910@`75.127.200.98` view NightSection as
select `u684207109_cs5910`.`Section`.`CourseRegistrationNumber` AS `CourseRegistrationNumber`,
       `u684207109_cs5910`.`Section`.`CourseID`                 AS `CourseID`,
       `u684207109_cs5910`.`Section`.`SectionNumber`            AS `SectionNumber`,
       `u684207109_cs5910`.`Section`.`FacultyID`                AS `FacultyID`,
       `u684207109_cs5910`.`Section`.`TimeSlotNum`              AS `TimeSlotNum`,
       `u684207109_cs5910`.`Section`.`SeatsCapacity`            AS `SeatsCapacity`,
       `u684207109_cs5910`.`Section`.`RoomID`                   AS `RoomID`,
       `u684207109_cs5910`.`Section`.`BuildingName`             AS `BuildingName`,
       `u684207109_cs5910`.`Section`.`Semester`                 AS `Semester`,
       `u684207109_cs5910`.`Section`.`Year`                     AS `Year`
from `u684207109_cs5910`.`Section`
where `u684207109_cs5910`.`Section`.`TimeSlotNum` in (select `u684207109_cs5910`.`TimeSlotNew`.`ID`
                                                      from `u684207109_cs5910`.`TimeSlotNew`
                                                      where `u684207109_cs5910`.`TimeSlotNew`.`StartTime` > '17:00:00');

