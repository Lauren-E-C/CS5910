create definer = u684207109_cs5910@`75.127.200.98` view SectionCourse as
select `u684207109_cs5910`.`Section`.`CourseRegistrationNumber` AS `CourseRegistrationNumber`,
       `u684207109_cs5910`.`Section`.`CourseID`                 AS `CourseID`,
       `u684207109_cs5910`.`Section`.`SectionNumber`            AS `SectionNumber`,
       `u684207109_cs5910`.`Section`.`FacultyID`                AS `FacultyID`,
       `u684207109_cs5910`.`Section`.`TimeSlotNum`              AS `TimeSlotNum`,
       `u684207109_cs5910`.`Section`.`SeatsCapacity`            AS `SeatsCapacity`,
       `u684207109_cs5910`.`Section`.`RoomID`                   AS `RoomID`,
       `u684207109_cs5910`.`Section`.`BuildingName`             AS `BuildingName`,
       `u684207109_cs5910`.`Section`.`Semester`                 AS `Semester`,
       `u684207109_cs5910`.`Section`.`Year`                     AS `Year`,
       `u684207109_cs5910`.`Course`.`departmentcode`            AS `departmentcode`,
       `u684207109_cs5910`.`Course`.`coursenumber`              AS `coursenumber`,
       `u684207109_cs5910`.`Course`.`coursename`                AS `coursename`,
       `u684207109_cs5910`.`Course`.`description`               AS `description`,
       `u684207109_cs5910`.`Course`.`level`                     AS `level`,
       `u684207109_cs5910`.`Course`.`prerequisites`             AS `prerequisites`,
       `u684207109_cs5910`.`Course`.`credits`                   AS `credits`
from `u684207109_cs5910`.`Section`
         join `u684207109_cs5910`.`Course`
where `u684207109_cs5910`.`Section`.`CourseID` = `u684207109_cs5910`.`Course`.`courseID`;

