create definer = u684207109_cs5910@`75.127.200.98` view StudentHoldView as
select `u684207109_cs5910`.`usertable`.`ID`           AS `ID`,
       `u684207109_cs5910`.`usertable`.`lastName`     AS `lastName`,
       `u684207109_cs5910`.`usertable`.`firstName`    AS `firstName`,
       `u684207109_cs5910`.`usertable`.`phoneNumber`  AS `phoneNumber`,
       `u684207109_cs5910`.`usertable`.`email`        AS `email`,
       `u684207109_cs5910`.`usertable`.`address`      AS `address`,
       `u684207109_cs5910`.`usertable`.`town`         AS `town`,
       `u684207109_cs5910`.`usertable`.`zip`          AS `zip`,
       `u684207109_cs5910`.`usertable`.`pWord`        AS `pWord`,
       `u684207109_cs5910`.`usertable`.`uLocked`      AS `uLocked`,
       `u684207109_cs5910`.`usertable`.`uType`        AS `uType`,
       `u684207109_cs5910`.`usertable`.`state`        AS `state`,
       `u684207109_cs5910`.`usertable`.`country`      AS `country`,
       `u684207109_cs5910`.`usertable`.`failedLogins` AS `failedLogins`,
       `u684207109_cs5910`.`usertable`.`name`         AS `name`,
       `u684207109_cs5910`.`StudentHolds`.`StudentID` AS `StudentID`,
       `u684207109_cs5910`.`StudentHolds`.`HoldName`  AS `HoldName`
from (`u684207109_cs5910`.`usertable`
         left join `u684207109_cs5910`.`StudentHolds`
                   on (`u684207109_cs5910`.`usertable`.`ID` = `u684207109_cs5910`.`StudentHolds`.`StudentID`));

